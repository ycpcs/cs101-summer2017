// CS101-106 Exam 1: Question 12
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here

	return 0;
}
