// CS101 Exam 3-106: Question 15
#include <stdio.h>

#define MAX 10

int neg_sum(int arrayValues[], int arraySize);

int main(void) {
	// IMPORTANT!!! Do not change the code in the main
	// function in any way!

	int n;
	printf("How many values? ");
	scanf("%i", &n);

	if (n > MAX) {
		printf("Too many values\n");
		return 1;
	}

	printf("Enter values: ");
	int values[MAX];
	for (int i = 0; i < n; i++) {
		scanf("%i", &values[i]);
	}

    // TODO: add a function call to neg_sum and capture return value in 'sum'
    
	printf("Sum of negative values is %i\n", sum);
	return 0;
}

// TODO: add a definition for the neg_sum function

