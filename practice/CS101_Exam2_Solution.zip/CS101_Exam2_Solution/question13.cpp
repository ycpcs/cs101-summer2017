// CS101-105 Exam 2: Question 13

#include <stdio.h>
#include <math.h>

int main(void) {
	// Declare variables for day number of Sunday and number of
	// days in the month
	int start, days_in_month;
	
	// Read input values
	printf("Enter start day, days in month: ");
	scanf("%i %i", &start, &days_in_month);
	
	// Declare loop variable for current day, initialize it
	int day = start;
	
	// Loop to print the day numbers for the week
	for (int i = 1; i <= 7; i++) {
		printf("%i ", day);
		day++;
		if (day > days_in_month) {
			// go to first day of next month
			day = 1;
		}
	}
	printf("\n");
	
	return 0;
}
