// CS101-105 Exam 2: Question 14
#include <stdio.h>
#include <math.h>

int main(void) {
	int min = 101, max = 0;
	double sum = 0.0;

	int num_exams;
	printf("Enter number of exams: ");
	scanf("%i", &num_exams);

	for (int i = 1; i <= num_exams; i++) {
		printf("Enter next exam score (0-100): ");
		int score;
		scanf("%i", &score);

		// Update min if this is the new minimum score
		if (score < min) {
			min = score;
		}
		// Update max if this is the new maximum score
		if (score > max) {
			max = score;
		}
		// Update the sum
		sum += score;
	}

	// Adjust sum by subtracting the lowest score
	sum -= min;

	double avg = sum / (num_exams - 1);

	printf("Min: %i, Max: %i, Mean of 2 highest exams: %.2lf\n", min, max, avg);

	return 0;
}
