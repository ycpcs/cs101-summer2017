// CS101-105 Exam 2: Question 15
#include <stdio.h>
#include <math.h>
#define SIZE 20

int main(void) {
	// DO NOT MODIFY
	int num_vals = 0;
	int data[SIZE];
	int target = 0;
	
	// Get user input
	printf("Enter number of values: ");
	scanf("%i", &num_vals);
	
	for (int i = 0; i < num_vals; i++) {
		scanf("%i", &data[i]);
	}
	
	printf("Enter target value: ");
	scanf("%i", &target);
	// DO NOT MODIFY
	
	int num_greater = 0, num_greater_total = 0;
	int num_less = 0, num_less_total = 0;
	int num_equal = 0, num_equal_total = 0;

	for (int i = 0; i < num_vals - 2; i++) {
		int triple = data[i] + data[i+1] + data[i+2];
		if (triple < target) {
			num_less++;
			num_less_total += triple;
		} else if (triple > target) {
			num_greater++;
			num_greater_total += triple;
		} else {
			num_equal++;
			num_equal_total += triple;
		}
	}

	printf("There are %i triples greater than %i with total %i\n",
		num_greater, target, num_greater_total);
	printf("There are %i triples less than %i with total %i\n",
		num_less, target, num_less_total);
	printf("There are %i triples equal to %i with total %i\n",
		num_equal, target, num_equal_total);

	if (num_greater > num_equal && num_greater > num_less) {
		printf("Greater has the largest total\n");
	} else if (num_less > num_equal && num_less > num_greater) {
		printf("Less has the largest total\n");
	} else {
		printf("Equal has the largest total\n");
	}

	return 0;
}
