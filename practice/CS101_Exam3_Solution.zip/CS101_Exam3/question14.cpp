// CS101 Exam 3-106: Question 14
#include <stdio.h>
#include <math.h>

// Start: DO NOT MODIFY
double compute_distance(double x1, double y1, double x2, double y2);
bool does_intersect(double x1, double y1, double r1, double x2, double y2, double r2);
// End: DO NOT MODIFY

int main(void) {
	// Start: DO NOT MODIFY
	double cx1, cy1, cr1;   // circle 1 values
	double cx2, cy2, cr2;   // circle 2 values
	printf("Enter x, y, and r values for circle 1: ");
	scanf("%lf %lf %lf", &cx1, &cy1, &cr1);
	printf("Enter x, y, and r values for circle 2: ");
	scanf("%lf %lf %lf", &cx2, &cy2, &cr2);

	bool intersect = does_intersect(cx1,cy1,cr1,cx2,cy2,cr2);
	if (intersect) {
		printf("The circles intersect\n");
	} else {
		printf("The circles do not intersect\n");
	}
	// End: DO NOT MODIFY

	return 0;
}

//----------------------------------------------------------------------------	
// TODO: add definitions for the compute_distance and does_intersect functions


double compute_distance(double x1, double y1, double x2, double y2) {
	double dist;
	double xdiff = x2 - x1;
	double ydiff = y2 - y1;
	dist = sqrt(xdiff*xdiff + ydiff*ydiff);
	return dist;
}

bool does_intersect(double x1, double y1, double r1, double x2, double y2, double r2) {
	// compute distance between centers
	double dist = compute_distance(x1, y1, x2, y2);

	// compute sum of radii
	double sum_radii = r1 + r2;

	// Note that in general it is poor design to have a
	// function that returns a value also print output.
	// However, printing the distance between the centers
	// and the sum of the radii was part of the specification
	// for this function.
	printf("The distance between the centers is %.2f\n", dist);
	printf("The sum of the radii is %.2f\n", sum_radii);

	// the circles intersect if the distance between the centers
	// is smaller than the sum of the radii.
	return dist < sum_radii;
}
