// CS101 Exam 3-106: Question 13
#include <stdio.h>

//-------------------------------- P A R T   1 ----------------------------------	
// TODO 1: Insert function prototypes here
int get_whole_dollars(int num_cents);
int get_change(int num_cents);


int main(void) {
	// Start: DO NOT MODIFY
	int cents;
	int d,c;
	printf("Number of cents: ");
	scanf("%i", &cents);
	// End: DO NOT MODIFY

	//-------------------------------- P A R T   2 ----------------------------------	
	// TODO 2: Insert function calls here
	//         Store results from get_whole_dollars in d
	//         Store results from get_change in c
	d = get_whole_dollars(cents);
	c = get_change(cents);


	// Start: DO NOT MODIFY
	printf("Whole dollars=%i\n", d);
	printf("Change=%i\n", c);
	// End: DO NOT MODIFY

	return 0;
}

//-------------------------------- P A R T   3 ----------------------------------	
// TODO 3: add definitions for the get_whole_dollars and get_change functions

int get_whole_dollars(int num_cents) {
	int dollars;
	dollars = num_cents / 100;
	return dollars;
}

int get_change(int num_cents) {
	int change;
	change = num_cents % 100;
	return change;
}
