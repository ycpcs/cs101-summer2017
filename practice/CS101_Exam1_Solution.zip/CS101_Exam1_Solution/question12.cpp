// CS101-106 Exam 1: Question 12
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here
	double earth_height, moon_height;

	printf("Input initial height on Earth: ");
	scanf("%lf", &earth_height);

	printf("Input initial height on the moon: ");
	scanf("%lf", &moon_height);

	// acceleration due to gravity on the Earth and moon,
	// in m/s
	double earth_accel = 9.81;
	double moon_accel = 1.62;

	// compute velocities at impact
	double earth_vel, moon_vel;
	earth_vel = earth_accel * sqrt((2.0 * earth_height) / earth_accel);
	moon_vel = moon_accel * sqrt((2.0 * moon_height) / moon_accel);

	// print Earth object height and velocity at impact
	printf("Object dropped from a height of %.2lf meters on Earth\n", earth_height);
	printf("Velocity at impact was %.2lf m/s on Earth\n", earth_vel);

	// print moon object height and velocity at impact
	printf("Object dropped from a height of %.2lf meters on the moon\n", moon_height);
	printf("Velocity at impact was %.2lf m/s on Earth\n", moon_vel);

	// compare impact velocities
	if (earth_vel > moon_vel) {
		printf("The velocity on Earth was greater than on the moon\n");
	} else {
		printf("The velocity on the moon was greater than on Earth\n");
	}

	return 0;
}
