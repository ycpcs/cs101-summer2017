// CS101-106 Exam 1: Question 14
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here
	int bday_month, bday_day;
	int current_month, current_day;

	printf("Enter the month of your birthday: ");
	scanf("%i", &bday_month);

	printf("Enter the day of your birthday: ");
	scanf("%i", &bday_day);

	printf("Enter today's month: ");
	scanf("%i", &current_month);

	printf("Enter today's day: ");
	scanf("%i", &current_day);

	if (bday_month == current_month && bday_day == current_day) {
		printf("Happy birthday, today is your birthday!\n");
	} else if (bday_month < current_month ||
	           (bday_month == current_month && bday_day < current_day)) {
		printf("Your birthday was in the past.\n");
	} else {
		printf("Your birthday is in the future.\n");
	}

	return 0;
}
