// CS101-106 Exam 1: Question 13
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here
	int num_quarters;

	printf("How many quarters? ");
	scanf("%i", &num_quarters);

	// determine how many cents the quarters are worth
	int value_in_cents;
	value_in_cents = num_quarters * 25;

	// determine the number of whole dollars
	int dollars;
	dollars = value_in_cents / 100;

	// determine number of cents left over
	int cents;
	cents = value_in_cents % 100;

	printf("Dollars: %i\n", dollars);
	printf("Cents: %i\n", cents);

	return 0;
}
