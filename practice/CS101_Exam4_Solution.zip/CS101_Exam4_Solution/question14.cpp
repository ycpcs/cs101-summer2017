// CS101 Exam 4-106: Question 14
#include <stdio.h>
#include <math.h>

// Start: DO NOT MODIFY
struct Point {
	double x;
	double y;
};

struct Circle {
	struct Point center;
	double radius;
};

double compute_distance(struct Point p1, struct Point p2);
bool does_intersect(struct Circle *cir1, struct Circle *cir2);
// End: DO NOT MODIFY

int main(void) {
	// Start: DO NOT MODIFY
	struct Circle c1, c2;
	printf("Enter x, y, and r values for circle 1: ");
	scanf("%lf %lf %lf", &c1.center.x, &c1.center.y, &c1.radius);
	printf("Enter x, y, and r values for circle 2: ");
	scanf("%lf %lf %lf", &c2.center.x, &c2.center.y, &c2.radius);

	bool intersect = does_intersect(&c1,&c2);
	if (intersect) {
		printf("The circles intersect\n");
	} else {
		printf("The circles do not intersect\n");
	}
	// End: DO NOT MODIFY

	return 0;
}

//----------------------------------------------------------------------------	
// TODO: add definitions for the compute_distance and does_intersect functions

double compute_distance(struct Point p1, struct Point p2) {
	double xdist = p1.x - p2.x;
	double ydist = p1.y - p2.y;
	return sqrt(xdist*xdist + ydist*ydist);
}

bool does_intersect(struct Circle *cir1, struct Circle *cir2) {
	double center_dist = compute_distance(cir1->center, cir2->center);
	double sum_radii = cir1->radius + cir2->radius;
	printf("The distance between the centers is %.2lf\n", center_dist);
	printf("The sum of the radii is %.2lf\n", sum_radii);
	return center_dist < sum_radii;
}
