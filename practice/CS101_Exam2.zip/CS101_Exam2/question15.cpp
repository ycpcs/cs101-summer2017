// CS101-105 Exam 2: Question 15
#include <stdio.h>
#include <math.h>
#define SIZE 20

int main(void) {
	// DO NOT MODIFY
	int num_vals = 0;
	int data[SIZE];
	int target = 0;
	
	// Get user input
	printf("Enter number of values: ");
	scanf("%i", &num_vals);
	
	for (int i = 0; i < num_vals; i++) {
		scanf("%i", &data[i]);
	}
	
	printf("Enter target value: ");
	scanf("%i", &target);
	// DO NOT MODIFY
	
	// TODO: add your code here

	return 0;
}
