#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double computeMean(int arr[], int size);
double computeMedian(int arr[], int size);
double computeStDev(int arr[], int size);

// TODO: define constants

// This function can be used with qsort to sort
// the elements of an array of ints.
int compare(const void *left, const void *right) {
	return *(int*)left - *(int*)right;
}

int main(void) {
	// TODO: your code here

	return 0;
}
